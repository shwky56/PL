package user;
import java.io.Serializable;

public class LoginInfo implements Serializable{
    private String suename;
    private String pasworde;
    public  LoginInfo(){

    }
    public LoginInfo(String suenam, String pasword) {
        this.pasworde = pasword;
        this.suename = suenam;
    }
    public void setSuename(String suename) {
        this.suename = suename;
    }
    public void setPasworde(String pasworde) {
        this.pasworde = pasworde;
    }
    public String getPasworde() {
        return pasworde;
    }
    public String getSuename() {
        return suename;
    }
}
