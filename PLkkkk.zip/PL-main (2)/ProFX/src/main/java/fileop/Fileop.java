package fileop;
import com.example.profx.AddStudentInfo;
import com.example.profx.InstructorInfo;
import user.LoginInfo;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
public class Fileop implements  Serializable{
    public  static <E> ArrayList<E> read(File file, int a){
        Scanner readar = null;
        try{
            System.out.println("ryead wht"+ file.getAbsolutePath());
            readar = new Scanner(file);


        } catch (FileNotFoundException e) {
            e.printStackTrace();
            System.out.println(e);
        }
        if(a == 1){
            ArrayList<LoginInfo> loginf = new ArrayList<LoginInfo>();
            LoginInfo l;
            while(readar.hasNext()){
                l = new LoginInfo();
                String lion = readar.nextLine();
                String[] sepr = lion.split("@");
                l.setSuename(sepr[0]);
                l.setPasworde(sepr[1]);
                loginf.add(l);
            }
            return (ArrayList<E>) loginf;
        }
        if(a == 2){
            ArrayList<AddStudentInfo> loginf = new ArrayList<AddStudentInfo>();
            AddStudentInfo l;int i=0;
            while(readar.hasNext()){i++;
                l = new AddStudentInfo();
                String lion = readar.nextLine();
                String[] sepr = lion.split("@");
                l.setFirstName(sepr[0]);
                l.iii=i;
                loginf.add(l);
            }
            return (ArrayList<E>) loginf;
        }
        if(a == 3){
            ArrayList<InstructorInfo> loginf = new ArrayList<InstructorInfo>();
            InstructorInfo l;int i=0;
            while(readar.hasNext()){i++;
                l = new InstructorInfo();
               String lion = readar.nextLine();
                String[] sepr = lion.split("@");
                l.setInstName(sepr[0]);
                l.setInstDept(sepr[1]);
                l.setAddress(sepr[2]);
                l.setInstMail(sepr[3]);
                l.setInstPhone(sepr[4]);
                l.setGender( sepr[5]);
                loginf.add(l);
            }
            return (ArrayList<E>) loginf;
        }
        return null;
    }
    public static boolean ifuser(String usertype, LoginInfo user){
        ArrayList<LoginInfo> serch ;File file;
        if(usertype == "Admin")  file = new File("File//loginadmin");
        else if(usertype == "Instructor") file = new File("File//logininstractor");
        else  file = new File("File//loginstydent");
        serch = read(file, 1);
        for(var i: serch){
            if(i.getPasworde().equals( user.getPasworde()) && i.getSuename().equals(user.getSuename()))
                return true;
        }
        return false;
        //return  serch.contains(user);
    }
    public static boolean write(File file, String data, boolean append){
        PrintWriter writter = null;
        try{
            System.out.printf("savs");
            writter = new PrintWriter(new FileWriter(file, append));
            writter.println(data);
            System.out.printf("savs");
            writter.close();

            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }
    public static void writeop(File file, Object oop, boolean append) throws  Exception{
        FileOutputStream fos = new FileOutputStream(file, append);
        ObjectOutputStream wryer= new ObjectOutputStream(fos);
        System.out.printf("wri");
        wryer.writeObject(oop);
        wryer.close();
    }
    public static Object readoop(File file){
        Object rs = null;
        try{
            System.out.printf("read");
            ObjectInputStream read = new ObjectInputStream(new FileInputStream(file));
            rs = read.readObject();
        }  catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            System.out.printf(String.valueOf(e));
        }
        return rs;
    }

}